import React, { useEffect } from 'react';
import { useLocation } from "wouter";
import { motion } from "framer-motion";
import { RefreshCw } from "lucide-react";

export default function SplashScreen() {
  const [_, setLocation] = useLocation();

  useEffect(() => {
    const timer = setTimeout(() => {
      setLocation("/home");
    }, 3000);

    return () => clearTimeout(timer);
  }, [setLocation]);

  return (
    <div className="min-h-screen bg-primary flex flex-col items-center justify-center text-white p-4">
      <motion.div
        initial={{ scale: 0.5, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.8, ease: "easeOut" }}
        className="flex flex-col items-center"
      >
        <RefreshCw size={100} className="mb-6 animate-spin-slow" style={{ animationDuration: '3s' }} />
        
        <motion.h1 
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.3, duration: 0.6 }}
          className="text-4xl md:text-5xl font-bold text-center tracking-wider mb-12"
        >
          Welcome
          <br />
          JJConverter
        </motion.h1>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.8 }}
        >
          <div className="w-12 h-12 border-4 border-white border-t-transparent rounded-full animate-spin"></div>
        </motion.div>
      </motion.div>
    </div>
  );
}
