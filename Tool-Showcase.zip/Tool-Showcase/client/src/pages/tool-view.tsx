import React, { useState, useRef, useEffect } from 'react';
import { useLocation, useRoute } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import { 
  ArrowLeft, Upload, File, CheckCircle2, Download, 
  Loader2, AlertCircle, FileText, Image, Table, X, Plus, GripVertical
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { convertFiles, getPdfPages, saveOrganizedPdf, type ExtractedPage } from "@/lib/converters";

// DnD Kit imports
import {
  DndContext, 
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  DragOverlay
} from '@dnd-kit/core';
import {
  arrayMove,
  SortableContext,
  sortableKeyboardCoordinates,
  useSortable,
  rectSortingStrategy,
} from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';

// Map tool IDs to icons/colors for consistency
const toolConfig: Record<string, any> = {
  'pdf-to-jpg': { name: 'PDF to JPG', icon: Image, color: 'text-red-500', accept: '.pdf', targetExt: 'jpg' },
  'pdf-to-word': { name: 'PDF to Word', icon: FileText, color: 'text-blue-500', accept: '.pdf', targetExt: 'docx' },
  'jpg-to-pdf': { name: 'JPG to PDF', icon: File, color: 'text-red-600', accept: '.jpg,.jpeg,.png', targetExt: 'pdf' },
  'merge-pdf': { name: 'Merge PDF', icon: File, color: 'text-purple-500', accept: '.pdf', targetExt: 'pdf' },
  'split-pdf': { name: 'Split PDF', icon: File, color: 'text-orange-500', accept: '.pdf', targetExt: 'zip' },
  'organize-pdf': { name: 'Organize PDF', icon: File, color: 'text-teal-500', accept: '.pdf', targetExt: 'pdf' },
  'pdf-to-excel': { name: 'PDF to Excel', icon: Table, color: 'text-green-500', accept: '.pdf', targetExt: 'xlsx' },
  'excel-to-pdf': { name: 'Excel to PDF', icon: File, color: 'text-green-700', accept: '.xlsx,.xls', targetExt: 'pdf' },
  'pdf-to-ppt': { name: 'PDF to PPT', icon: File, color: 'text-orange-600', accept: '.pdf', targetExt: 'pptx' },
  'ppt-to-pdf': { name: 'PPT to PDF', icon: File, color: 'text-orange-700', accept: '.pptx,.ppt', targetExt: 'pdf' },
};

function SortablePageItem({ page, onRemove }: { page: ExtractedPage, onRemove: (id: string) => void }) {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging
  } = useSortable({ id: page.id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    zIndex: isDragging ? 999 : 1,
  };

  return (
    <div 
      ref={setNodeRef} 
      style={style}
      className={`relative group bg-white rounded-lg shadow-sm border ${isDragging ? 'border-primary shadow-lg scale-105' : 'border-gray-200'} overflow-hidden aspect-[1/1.4] flex flex-col`}
    >
      <div className="absolute top-2 right-2 z-10 opacity-0 group-hover:opacity-100 transition-opacity">
        <button 
          onClick={(e) => { e.stopPropagation(); onRemove(page.id); }}
          className="bg-red-500 text-white p-1 rounded-full shadow-md hover:bg-red-600"
        >
          <X size={14} />
        </button>
      </div>
      
      <div 
        {...attributes} 
        {...listeners}
        className="flex-1 p-2 cursor-grab active:cursor-grabbing bg-gray-50 flex items-center justify-center overflow-hidden"
      >
        <img src={page.imgUrl} alt={`Page ${page.pageIndex}`} className="max-w-full max-h-full object-contain shadow-sm" />
      </div>
      
      <div className="bg-white p-2 text-xs text-center border-t border-gray-100 truncate text-gray-500 px-1">
        Page {page.pageIndex}
      </div>
    </div>
  );
}

export default function ToolView() {
  const [match, params] = useRoute("/tool/:id");
  const [location, setLocation] = useLocation();
  const { toast } = useToast();
  const toolId = params?.id || '';
  const config = toolConfig[toolId] || { name: 'Unknown Tool', icon: AlertCircle, color: 'text-gray-500', accept: '*', targetExt: 'txt' };
  
  const [files, setFiles] = useState<File[]>([]);
  const [extractedPages, setExtractedPages] = useState<ExtractedPage[]>([]);
  const [result, setResult] = useState<{ blob: Blob, fileName: string } | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [status, setStatus] = useState<'idle' | 'extracting' | 'organizing' | 'uploading' | 'processing' | 'done'>('idle');
  const [progress, setProgress] = useState(0);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // DnD Sensors
  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 8 } }),
    useSensor(KeyboardSensor, { coordinateGetter: sortableKeyboardCoordinates })
  );

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      handleFiles(Array.from(e.dataTransfer.files));
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      handleFiles(Array.from(e.target.files));
    }
  };

  const handleFiles = async (newFiles: File[]) => {
    if (toolId === 'organize-pdf') {
      setStatus('extracting');
      const pages = await getPdfPages(newFiles);
      setExtractedPages(prev => [...prev, ...pages]);
      setFiles(prev => [...prev, ...newFiles]); // Keep track of files for reference if needed
      setStatus('organizing');
    } else {
      setFiles(prev => [...prev, ...newFiles]);
    }
  };

  const removeFile = (index: number) => {
    setFiles(prev => prev.filter((_, i) => i !== index));
  };

  const removePage = (id: string) => {
    setExtractedPages(prev => prev.filter(p => p.id !== id));
  };

  const handleDragEnd = (event: any) => {
    const { active, over } = event;
    if (active.id !== over.id) {
      setExtractedPages((items) => {
        const oldIndex = items.findIndex(i => i.id === active.id);
        const newIndex = items.findIndex(i => i.id === over.id);
        return arrayMove(items, oldIndex, newIndex);
      });
    }
  };

  const startConversion = async () => {
    if (toolId === 'organize-pdf' && extractedPages.length === 0) return;
    if (toolId !== 'organize-pdf' && files.length === 0) return;
    
    setStatus('uploading');
    setProgress(10);

    try {
      // Simulate upload
      await new Promise(r => setTimeout(r, 800));
      setProgress(40);
      setStatus('processing');
      
      let conversionResult;
      
      if (toolId === 'organize-pdf') {
        const blob = await saveOrganizedPdf(extractedPages);
        conversionResult = { blob, fileName: 'organized.pdf' };
      } else {
        conversionResult = await convertFiles(files, toolId);
      }
      
      setResult(conversionResult);
      setProgress(100);
      setStatus('done');
      toast({
        title: "Success!",
        description: `Successfully processed your file(s).`,
      });
    } catch (error) {
      console.error("Conversion failed:", error);
      setStatus('idle');
      toast({
        title: "Error",
        description: "Failed to process files. Please try again.",
        variant: "destructive"
      });
    }
  };

  const handleDownload = () => {
    if (!result) return;
    
    const url = URL.createObjectURL(result.blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = result.fileName;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    toast({
      title: "Downloaded",
      description: `${result.fileName} has been saved.`,
    });
  };

  const reset = () => {
    setFiles([]);
    setExtractedPages([]);
    setResult(null);
    setStatus('idle');
    setProgress(0);
  };

  const ToolIcon = config.icon;

  return (
    <div className="min-h-screen bg-background p-6 font-sans flex flex-col items-center">
      <div className="w-full max-w-4xl">
        {/* Header */}
        <div className="flex items-center mb-8">
          <button 
            onClick={() => setLocation('/home')}
            className="p-2 -ml-2 hover:bg-gray-100 rounded-full transition-colors mr-4"
          >
            <ArrowLeft className="text-gray-600" />
          </button>
          <div className={`p-2 rounded-lg bg-gray-100 mr-4`}>
            <ToolIcon className={`w-6 h-6 ${config.color}`} />
          </div>
          <h1 className="text-2xl font-bold text-gray-800">{config.name}</h1>
        </div>

        {/* Main Card */}
        <div className="bg-white rounded-[24px] shadow-sm border border-gray-100 overflow-hidden min-h-[500px] flex flex-col relative">
          
          <AnimatePresence mode="wait">
            {status === 'idle' && (
              <motion.div 
                key="idle"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="flex-1 flex flex-col items-center p-8 text-center h-full"
              >
                {files.length === 0 ? (
                  <div className="flex-1 w-full flex flex-col justify-center">
                    <div 
                      onClick={() => fileInputRef.current?.click()}
                      onDragOver={handleDragOver}
                      onDragLeave={handleDragLeave}
                      onDrop={handleDrop}
                      className={`w-full h-64 border-2 border-dashed rounded-2xl flex flex-col items-center justify-center cursor-pointer transition-colors ${isDragging ? 'border-primary bg-primary/5' : 'border-gray-200 hover:border-primary/50 hover:bg-gray-50'}`}
                    >
                      <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mb-4">
                        <Upload className="text-primary w-8 h-8" />
                      </div>
                      <h3 className="text-lg font-semibold text-gray-800 mb-2">Select your files</h3>
                      <p className="text-gray-500 text-sm max-w-xs">
                        Drag and drop files here or click to browse
                      </p>
                      <input 
                        type="file" 
                        ref={fileInputRef} 
                        className="hidden" 
                        accept={config.accept}
                        onChange={handleFileSelect}
                        multiple
                      />
                    </div>
                  </div>
                ) : (
                  // STANDARD FILE LIST VIEW (for non-organizer tools)
                   <div className="w-full h-full flex flex-col">
                    <div className="flex items-center justify-between mb-4 px-1">
                      <h3 className="text-lg font-semibold text-gray-800">Selected Files ({files.length})</h3>
                      <button 
                         onClick={() => fileInputRef.current?.click()}
                         className="text-sm text-primary font-medium hover:bg-primary/5 px-3 py-1.5 rounded-lg transition-colors flex items-center gap-1"
                      >
                        <Plus size={16} />
                        Add more
                      </button>
                      <input 
                        type="file" 
                        ref={fileInputRef} 
                        className="hidden" 
                        accept={config.accept}
                        onChange={handleFileSelect}
                        multiple
                      />
                    </div>

                    <div className="flex-1 overflow-y-auto w-full space-y-2 mb-4 pr-1 max-h-[350px] scrollbar-thin scrollbar-thumb-gray-200 scrollbar-track-transparent">
                      {files.map((file, index) => (
                        <motion.div 
                          key={`${file.name}-${index}`}
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, x: -10 }}
                          className="flex items-center justify-between p-3 bg-gray-50 rounded-xl border border-gray-100 group hover:border-primary/20 transition-all"
                        >
                          <div className="flex items-center gap-3 overflow-hidden">
                            <div className="p-2 bg-white rounded-lg border border-gray-100 text-gray-500">
                               <File size={20} />
                            </div>
                            <div className="flex flex-col min-w-0 text-left">
                              <span className="text-sm font-medium text-gray-700 truncate max-w-[200px] sm:max-w-[300px]">{file.name}</span>
                              <span className="text-xs text-gray-400">{(file.size / 1024 / 1024).toFixed(2)} MB</span>
                            </div>
                          </div>
                          <button
                            onClick={(e) => { e.stopPropagation(); removeFile(index); }}
                            className="p-2 hover:bg-red-50 text-gray-400 hover:text-red-500 rounded-lg transition-colors"
                            title="Remove file"
                          >
                            <X size={18} />
                          </button>
                        </motion.div>
                      ))}
                    </div>

                    <div className="pt-4 border-t border-gray-100 mt-auto">
                      <div className="flex items-center justify-between mb-4 text-sm text-gray-500">
                        <span>Total size: {(files.reduce((acc, f) => acc + f.size, 0) / 1024 / 1024).toFixed(2)} MB</span>
                        <button onClick={reset} className="text-red-500 hover:underline">Clear all</button>
                      </div>
                      <button 
                        onClick={startConversion}
                        className="w-full bg-primary text-white py-3 rounded-xl font-semibold shadow-lg shadow-primary/30 hover:bg-primary/90 transition-all hover:scale-[1.02] active:scale-[0.98]"
                      >
                        {files.length > 1 ? 'Convert All' : `Convert to ${config.name.split('to')[1] || 'Output'}`}
                      </button>
                    </div>
                  </div>
                )}
              </motion.div>
            )}

            {status === 'extracting' && (
              <motion.div 
                key="extracting"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="flex-1 flex flex-col items-center justify-center p-12 text-center"
              >
                <Loader2 className="w-12 h-12 text-primary animate-spin mb-4" />
                <h3 className="text-xl font-bold text-gray-800 mb-2">Extracting Pages...</h3>
                <p className="text-gray-500">Please wait while we prepare your document organizer.</p>
              </motion.div>
            )}

            {/* ORGANIZER VIEW */}
            {status === 'organizing' && (
              <motion.div 
                 key="organizing"
                 initial={{ opacity: 0 }}
                 animate={{ opacity: 1 }}
                 exit={{ opacity: 0 }}
                 className="flex-1 flex flex-col p-6 h-full"
              >
                <div className="flex items-center justify-between mb-6">
                  <div>
                    <h3 className="text-lg font-bold text-gray-800">Organize Pages</h3>
                    <p className="text-sm text-gray-500">Drag pages to reorder. Click X to remove.</p>
                  </div>
                  <div className="flex gap-2">
                    <button 
                         onClick={() => fileInputRef.current?.click()}
                         className="text-sm bg-gray-100 hover:bg-gray-200 text-gray-700 font-medium px-4 py-2 rounded-lg transition-colors flex items-center gap-2"
                      >
                        <Plus size={16} />
                        Add File
                      </button>
                      <button onClick={reset} className="text-sm text-red-500 hover:bg-red-50 px-4 py-2 rounded-lg transition-colors">
                        Clear All
                      </button>
                  </div>
                   <input 
                      type="file" 
                      ref={fileInputRef} 
                      className="hidden" 
                      accept={config.accept}
                      onChange={handleFileSelect}
                      multiple
                    />
                </div>

                <div className="flex-1 overflow-y-auto bg-gray-50 rounded-xl p-4 border border-gray-100 mb-4 min-h-[300px]">
                   <DndContext 
                      sensors={sensors}
                      collisionDetection={closestCenter}
                      onDragEnd={handleDragEnd}
                   >
                      <SortableContext 
                        items={extractedPages.map(p => p.id)}
                        strategy={rectSortingStrategy}
                      >
                        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
                          {extractedPages.map((page) => (
                            <SortablePageItem key={page.id} page={page} onRemove={removePage} />
                          ))}
                        </div>
                      </SortableContext>
                   </DndContext>
                </div>

                <div className="pt-2">
                   <button 
                        onClick={startConversion}
                        className="w-full bg-primary text-white py-3 rounded-xl font-semibold shadow-lg shadow-primary/30 hover:bg-primary/90 transition-all hover:scale-[1.02] active:scale-[0.98]"
                      >
                        Merge & Download PDF
                      </button>
                </div>
              </motion.div>
            )}

            {(status === 'uploading' || status === 'processing') && (
              <motion.div 
                key="processing"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="flex-1 flex flex-col items-center justify-center p-12 text-center"
              >
                <div className="w-24 h-24 mb-8 relative flex items-center justify-center">
                  <svg className="w-full h-full transform -rotate-90">
                    <circle
                      cx="48"
                      cy="48"
                      r="40"
                      stroke="currentColor"
                      strokeWidth="8"
                      fill="transparent"
                      className="text-gray-100"
                    />
                    <circle
                      cx="48"
                      cy="48"
                      r="40"
                      stroke="currentColor"
                      strokeWidth="8"
                      fill="transparent"
                      strokeDasharray={251.2}
                      strokeDashoffset={251.2 - (251.2 * progress) / 100}
                      className="text-primary transition-all duration-300 ease-out"
                    />
                  </svg>
                  <div className="absolute inset-0 flex items-center justify-center text-xl font-bold text-primary">
                    {Math.round(progress)}%
                  </div>
                </div>
                <h3 className="text-2xl font-bold text-gray-800 mb-2">
                  {status === 'uploading' ? 'Uploading...' : 'Processing...'}
                </h3>
                <p className="text-gray-500">
                   Building your new PDF...
                </p>
              </motion.div>
            )}

            {status === 'done' && (
              <motion.div 
                key="done"
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="flex-1 flex flex-col items-center justify-center p-8 text-center"
              >
                <div className="w-20 h-20 bg-green-100 text-green-600 rounded-full flex items-center justify-center mb-6">
                  <CheckCircle2 size={40} />
                </div>
                <h3 className="text-2xl font-bold text-gray-800 mb-2">Complete!</h3>
                <p className="text-gray-500 mb-8 max-w-xs mx-auto">
                  Your organized PDF is ready.
                </p>
                <div className="flex gap-4">
                  <button 
                    onClick={reset}
                    className="px-6 py-3 rounded-xl font-semibold text-gray-600 hover:bg-gray-100 transition-colors"
                  >
                    Start Over
                  </button>
                  <button 
                    onClick={handleDownload}
                    className="bg-primary text-white px-8 py-3 rounded-xl font-semibold shadow-lg shadow-primary/30 hover:bg-primary/90 transition-all hover:scale-105 flex items-center gap-2"
                  >
                    <Download size={20} />
                    Download PDF
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

        </div>
        
        <p className="text-center text-gray-400 text-sm mt-8">
          By using this service, you agree to our Terms of Service and Privacy Policy.
        </p>
      </div>
    </div>
  );
}
