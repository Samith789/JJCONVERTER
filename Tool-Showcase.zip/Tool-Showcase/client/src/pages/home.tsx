import React, { useState, useEffect } from 'react';
import { 
  Image, FileText, File, Merge, Split, Layers, 
  Table, FileSpreadsheet, Presentation, FileCheck, X,
  Megaphone
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { useToast } from "@/hooks/use-toast";

// --- Fake Ad Component ---
function FakeAdDialog({ isOpen, onClose }: { isOpen: boolean, onClose: () => void }) {
  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4"
      >
        <motion.div
          initial={{ scale: 0.9, opacity: 0, y: 20 }}
          animate={{ scale: 1, opacity: 1, y: 0 }}
          exit={{ scale: 0.9, opacity: 0, y: 20 }}
          className="bg-white rounded-2xl shadow-2xl w-full max-w-sm overflow-hidden"
        >
          <div className="p-4 border-b border-gray-100 flex justify-between items-center bg-gray-50">
            <span className="font-semibold text-gray-700">Sponsored</span>
            <button 
              onClick={onClose}
              className="p-1 hover:bg-gray-200 rounded-full transition-colors"
            >
              <X size={20} className="text-gray-500" />
            </button>
          </div>
          <div className="h-48 bg-gray-100 flex flex-col items-center justify-center p-6 text-center">
             <Megaphone size={48} className="text-primary mb-4" />
             <h3 className="text-xl font-bold text-gray-800 mb-2">Super Cool Ad Here!</h3>
             <p className="text-gray-500 text-sm">Download our premium version to remove ads and unlock more features.</p>
          </div>
          <div className="p-4">
            <button 
              onClick={onClose}
              className="w-full py-3 bg-primary text-white font-semibold rounded-xl hover:bg-primary/90 transition-colors"
            >
              Close Ad (X)
            </button>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}

import { useLocation } from "wouter";

// --- Home Page ---
const tools = [
  { id: 'pdf-to-jpg', name: 'PDF to JPG', icon: Image, color: 'text-red-500', bg: 'bg-red-50' },
  { id: 'pdf-to-word', name: 'PDF to Word', icon: FileText, color: 'text-blue-500', bg: 'bg-blue-50' },
  { id: 'jpg-to-pdf', name: 'JPG to PDF', icon: File, color: 'text-red-600', bg: 'bg-red-50' },
  { id: 'merge-pdf', name: 'Merge PDF', icon: Merge, color: 'text-purple-500', bg: 'bg-purple-50' },
  { id: 'split-pdf', name: 'Split PDF', icon: Split, color: 'text-orange-500', bg: 'bg-orange-50' },
  { id: 'organize-pdf', name: 'Organize PDF', icon: Layers, color: 'text-teal-500', bg: 'bg-teal-50' },
  { id: 'pdf-to-excel', name: 'PDF to Excel', icon: Table, color: 'text-green-500', bg: 'bg-green-50' },
  { id: 'excel-to-pdf', name: 'Excel to PDF', icon: FileSpreadsheet, color: 'text-green-700', bg: 'bg-green-100' },
  { id: 'pdf-to-ppt', name: 'PDF to PPT', icon: Presentation, color: 'text-orange-600', bg: 'bg-orange-50' },
  { id: 'ppt-to-pdf', name: 'PPT to PDF', icon: FileCheck, color: 'text-orange-700', bg: 'bg-orange-100' },
];

export default function HomePage() {
  const [showAd, setShowAd] = useState(false);
  const [_, setLocation] = useLocation();
  const { toast } = useToast();

  useEffect(() => {
    // Show ad after a short delay to simulate "loading" or page entry
    const timer = setTimeout(() => {
      setShowAd(true);
    }, 500);
    return () => clearTimeout(timer);
  }, []);

  const handleToolClick = (id: string) => {
    setLocation(`/tool/${id}`);
  };

  return (
    <div className="min-h-screen bg-background text-foreground font-sans">
      <FakeAdDialog isOpen={showAd} onClose={() => setShowAd(false)} />

      {/* App Bar */}
      <header className="bg-white sticky top-0 z-10 px-6 py-4 shadow-sm flex items-center justify-center">
        <h1 className="text-xl font-bold text-gray-800 tracking-tight">JJConverter Tools</h1>
      </header>

      <main className="p-6 max-w-4xl mx-auto">
        <div className="mb-6">
          <h2 className="text-lg font-bold text-gray-800">Most Popular</h2>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
          {tools.map((tool, index) => (
            <motion.div
              key={tool.name}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
              whileHover={{ scale: 1.05, y: -5 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => handleToolClick(tool.id)}
              className="bg-white rounded-[20px] p-4 flex flex-col items-center justify-center aspect-[1.1] shadow-sm hover:shadow-md transition-shadow cursor-pointer border border-transparent hover:border-primary/10"
            >
              <div className={`p-4 rounded-full ${tool.bg} mb-4`}>
                <tool.icon className={`w-8 h-8 ${tool.color}`} />
              </div>
              <span className="font-semibold text-sm text-center text-gray-700 leading-tight">
                {tool.name}
              </span>
            </motion.div>
          ))}
        </div>
      </main>
    </div>
  );
}
