import { jsPDF } from "jspdf";
import * as pdfjsLib from 'pdfjs-dist';
import JSZip from 'jszip';

// Configure worker
import pdfjsWorker from 'pdfjs-dist/build/pdf.worker.mjs?url';
pdfjsLib.GlobalWorkerOptions.workerSrc = pdfjsWorker;

export interface ExtractedPage {
  id: string;
  imgUrl: string; // Data URL for display
  originalFile: File;
  pageIndex: number;
}

export async function convertFiles(files: File[], toolId: string): Promise<{ blob: Blob, fileName: string }> {
  if (files.length === 0) throw new Error("No files selected");

  switch (toolId) {
    case 'pdf-to-jpg':
      return await convertPdfToJpg(files);
    case 'jpg-to-pdf':
      return await convertJpgToPdf(files);
    case 'merge-pdf':
      return await mergePdfs(files);
    default:
      // Fallback
      return {
        blob: new Blob(
          [`[Demo Mode] Conversion for ${toolId} requires server-side processing. This is a placeholder. The PDF/Image tools are fully functional in this demo.`],
          { type: 'text/plain' }
        ),
        fileName: 'demo_result.txt'
      };
  }
}

async function convertJpgToPdf(files: File[]): Promise<{ blob: Blob, fileName: string }> {
  const pdf = new jsPDF();
  
  for (let i = 0; i < files.length; i++) {
    const file = files[i];
    if (i > 0) pdf.addPage();
    
    const imgData = await readFileAsDataURL(file);
    const imgProps = pdf.getImageProperties(imgData);
    const pdfWidth = pdf.internal.pageSize.getWidth();
    const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;
    
    pdf.addImage(imgData, 'JPEG', 0, 0, pdfWidth, pdfHeight);
  }
  
  return {
    blob: pdf.output('blob'),
    fileName: 'converted.pdf'
  };
}

async function convertPdfToJpg(files: File[]): Promise<{ blob: Blob, fileName: string }> {
  // If single file, return single JPG
  if (files.length === 1) {
    const jpgBlob = await renderPdfPageToJpg(files[0]);
    return {
      blob: jpgBlob,
      fileName: files[0].name.replace(/\.pdf$/i, '') + '.jpg'
    };
  }

  // If multiple, return ZIP
  const zip = new JSZip();
  
  for (const file of files) {
    const jpgBlob = await renderPdfPageToJpg(file);
    const name = file.name.replace(/\.pdf$/i, '') + '.jpg';
    zip.file(name, jpgBlob);
  }
  
  const content = await zip.generateAsync({ type: "blob" });
  return {
    blob: content,
    fileName: 'converted_images.zip'
  };
}

async function mergePdfs(files: File[]): Promise<{ blob: Blob, fileName: string }> {
  // Since we can't easily merge real PDFs client-side without heavy libs, 
  // we will render pages to images and put them in a new PDF (Rasterize Merge)
  const pdf = new jsPDF();
  let pageAdded = false;

  for (const file of files) {
    const arrayBuffer = await file.arrayBuffer();
    const originalPdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
    
    for (let pageNum = 1; pageNum <= originalPdf.numPages; pageNum++) {
      if (pageAdded) pdf.addPage();
      
      const page = await originalPdf.getPage(pageNum);
      const viewport = page.getViewport({ scale: 1.5 });
      
      const canvas = document.createElement('canvas');
      const context = canvas.getContext('2d');
      canvas.height = viewport.height;
      canvas.width = viewport.width;
      
      if (!context) continue;
      
      await page.render({ canvasContext: context, viewport } as any).promise;
      const imgData = canvas.toDataURL('image/jpeg', 0.8);
      
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = (viewport.height * pdfWidth) / viewport.width;
      
      pdf.addImage(imgData, 'JPEG', 0, 0, pdfWidth, pdfHeight);
      pageAdded = true;
    }
  }
  
  return {
    blob: pdf.output('blob'),
    fileName: 'merged.pdf'
  };
}

// --- Organize PDF Helpers ---

export async function getPdfPages(files: File[]): Promise<ExtractedPage[]> {
  const pages: ExtractedPage[] = [];

  for (const file of files) {
    try {
      const arrayBuffer = await file.arrayBuffer();
      const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
      
      for (let i = 1; i <= pdf.numPages; i++) {
        const page = await pdf.getPage(i);
        const viewport = page.getViewport({ scale: 0.5 }); // Thumbnail scale
        
        const canvas = document.createElement('canvas');
        const context = canvas.getContext('2d');
        canvas.height = viewport.height;
        canvas.width = viewport.width;
        
        if (context) {
          await page.render({ canvasContext: context, viewport } as any).promise;
          const imgUrl = canvas.toDataURL('image/jpeg', 0.7);
          
          pages.push({
            id: `${file.name}-page-${i}-${Date.now()}-${Math.random()}`,
            imgUrl,
            originalFile: file,
            pageIndex: i
          });
        }
      }
    } catch (err) {
      console.error("Error processing PDF pages for organize", err);
    }
  }
  
  return pages;
}

export async function saveOrganizedPdf(pages: ExtractedPage[]): Promise<Blob> {
  const pdf = new jsPDF();
  let pageAdded = false;

  for (const p of pages) {
    if (pageAdded) pdf.addPage();

    // We need to re-render the full quality page from the original file
    const arrayBuffer = await p.originalFile.arrayBuffer();
    const originalPdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
    const page = await originalPdf.getPage(p.pageIndex);
    
    // Scale for standard A4 or letter usually, but let's just fit to width
    const viewport = page.getViewport({ scale: 1.5 }); // Good quality for re-print
    
    const canvas = document.createElement('canvas');
    const context = canvas.getContext('2d');
    canvas.height = viewport.height;
    canvas.width = viewport.width;

    if (context) {
       await page.render({ canvasContext: context, viewport } as any).promise;
       const imgData = canvas.toDataURL('image/jpeg', 0.85);

       const pdfWidth = pdf.internal.pageSize.getWidth();
       const pdfHeight = (viewport.height * pdfWidth) / viewport.width;
       
       pdf.addImage(imgData, 'JPEG', 0, 0, pdfWidth, pdfHeight);
       pageAdded = true;
    }
  }

  return pdf.output('blob');
}


// Helpers
async function renderPdfPageToJpg(file: File): Promise<Blob> {
  const arrayBuffer = await file.arrayBuffer();
  const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
  const page = await pdf.getPage(1); // First page only for this demo tool
  const viewport = page.getViewport({ scale: 2.0 });
  
  const canvas = document.createElement('canvas');
  const context = canvas.getContext('2d');
  canvas.height = viewport.height;
  canvas.width = viewport.width;
  
  if (!context) throw new Error("Canvas context failed");
  
  await page.render({ canvasContext: context, viewport } as any).promise;
  
  return new Promise((resolve) => {
    canvas.toBlob((blob) => resolve(blob || new Blob([])), 'image/jpeg', 0.95);
  });
}

function readFileAsDataURL(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => resolve(e.target?.result as string);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}
